import Clock from './Clock';

export default Clock;
