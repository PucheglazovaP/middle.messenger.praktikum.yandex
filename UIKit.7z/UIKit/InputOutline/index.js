import InputOutline from './InputOutline';

export default InputOutline;
