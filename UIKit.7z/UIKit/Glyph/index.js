import Glyph from './Glyph';

export default Glyph;
