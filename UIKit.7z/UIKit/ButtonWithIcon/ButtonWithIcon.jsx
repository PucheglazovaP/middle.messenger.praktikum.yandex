import PropTypes from 'prop-types';
import Button from '../Button';
import Glyph from '../Glyph';
import { joinClassNames } from '../Utils';
import './ButtonWithIcon.css';

function ButtonWithIcon({
  className,
  primary,
  glyphNameLeft,
  glyphNameRight,
  children,
}) {
  return (
    <Button
      className={joinClassNames([
        'button_with_icon',
        {
          'button_with_icon--left': glyphNameLeft != null,
          'button_with_icon--right': glyphNameRight != null,
          'button_with_icon--no_child': children == null,
        },
        className,
      ])}
      primary={primary}
    >
      {glyphNameLeft ? (
        <Glyph name={glyphNameLeft} className="button_with_icon__glyph" />
      ) : null}
      {children}
      {glyphNameRight ? (
        <Glyph name={glyphNameRight} className="button_with_icon__glyph" />
      ) : null}
    </Button>
  );
}
ButtonWithIcon.propTypes = {
  className: PropTypes.string,
  primary: PropTypes.bool,
  glyphNameLeft: PropTypes.bool,
  glyphNameRight: PropTypes.bool,
  children: PropTypes.node,
};
ButtonWithIcon.defaultProps = {
  className: '',
  primary: false,
  glyphNameLeft: false,
  glyphNameRight: false,
  children: undefined,
};
export default ButtonWithIcon;
