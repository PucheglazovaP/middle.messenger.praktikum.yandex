import InputPassword from './InputPassword';

export default InputPassword;
