import Switcher from './Switcher';

export default Switcher;