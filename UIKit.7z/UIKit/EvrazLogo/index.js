import EvrazLogo from './EvrazLogo';

export default EvrazLogo;
