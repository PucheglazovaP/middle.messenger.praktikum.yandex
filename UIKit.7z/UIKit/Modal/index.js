import Modal from './Modal';

export * from './ModalContext';

export default Modal;
