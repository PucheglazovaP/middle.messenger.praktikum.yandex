import WellKeyValue from './WellKeyValue';

export default WellKeyValue;
