import InputStatic from './InputStatic';

export default InputStatic;
