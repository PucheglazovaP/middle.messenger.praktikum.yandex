import SelectStatic from './SelectStatic';

export default SelectStatic;
