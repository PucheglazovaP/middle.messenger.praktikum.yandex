import React from 'react';
import PropTypes from 'prop-types';
import { joinClassNames } from '../Utils';

import Spinner from '../Spinner/Spinner';

import ArrowDownIcon from './assets/ArrowDownIcon';
import ArrowUpIcon from './assets/ArrowUpIcon';

import '../index.css';
import './SelectStatic.css';

function SelectStatic({
  className,
  disabled,
  error,
  options,
  selectedOption,
  handleSelect,
  isLoading,
  isRequired,
  label,
  placeholder,
}) {
  const [isOpen, setIsOpen] = React.useState(false);

  function setStateHandler() {
    if (!isLoading && !disabled) {
      setIsOpen((prev) => !prev);
    }
  }

  function close() {
    setIsOpen(false);
  }

  function onOptionClicked(option) {
    return () => {
      if (option.value && option.displayValue) {
        handleSelect(option);
      }
      setIsOpen(false);
    };
  }

  return (
    <div
      className={joinClassNames([
        'select_static',
        Boolean(error) && 'status--error',
        disabled && 'status--disabled',
        className,
      ])}
    >
      {Boolean(label) && (
        <span className="select_static__label">
          <span>{label}</span>
          {isRequired && (
            <span className="select_static__required_marker">*</span>
          )}
        </span>
      )}
      <div
        role="button"
        className="select_static__selector"
        onClick={setStateHandler}
        onBlur={close}
        aria-hidden="true"
      >
        {selectedOption === null ? (
          <span className="select_static__placeholder">{placeholder}</span>
        ) : (
          <span className="select_static__value">
            {selectedOption.displayValue}
          </span>
        )}
        {isLoading ? (
          <div className="select_static__spinner">
            <Spinner />
          </div>
        ) : (
          <div className="select_static__arrow">
            {isOpen ? <ArrowUpIcon /> : <ArrowDownIcon />}
          </div>
        )}
      </div>
      {isOpen && (
        <div className="select_static__options">
          {options.map((item, index) => (
            <span
              role="button"
              key={`option-${index + 1}`}
              className="select_static__option"
              onClick={onOptionClicked(item)}
              aria-hidden="true"
            >
              {item.displayValue}
            </span>
          ))}
        </div>
      )}
      <p className="select_static__error">{error}</p>
    </div>
  );
}
SelectStatic.propTypes = {
  className: PropTypes.string,
  disabled: PropTypes.bool,
  error: PropTypes.string,
  isLoading: PropTypes.bool,
  isRequired: PropTypes.bool,
  label: PropTypes.string,
  handleSelect: PropTypes.func,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string,
      displayValue: PropTypes.string,
    }),
  ),
  selectedOption: PropTypes.shape({
    value: PropTypes.string,
    displayValue: PropTypes.string,
  }),
  placeholder: PropTypes.string,
};
SelectStatic.defaultProps = {
  className: '',
  disabled: false,
  error: '',
  isLoading: false,
  isRequired: false,
  label: '',
  handleSelect: () => {},
  options: [],
  selectedOption: { value: '', displayValue: '' },
  placeholder: '',
};

export default SelectStatic;
